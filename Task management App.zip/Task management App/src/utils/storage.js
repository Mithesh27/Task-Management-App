import { normalizeTasks } from './taskModel.js'

export const TASKS_STORAGE_KEY = 'task_app_tasks_v1'

export function loadTasks() {
  try {
    const raw = localStorage.getItem(TASKS_STORAGE_KEY)
    if (!raw) return []
    const parsed = JSON.parse(raw)
    return normalizeTasks(parsed)
  } catch {
    return []
  }
}

export function saveTasks(tasks) {
  try {
    localStorage.setItem(TASKS_STORAGE_KEY, JSON.stringify(tasks))
  } catch {
    // ignore write errors (private mode, storage full, etc.)
  }
}

