const PRIORITIES = ['low', 'medium', 'high']

function nowTs() {
  return Date.now()
}

function createId() {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID()
  }
  // Reasonable fallback for older browsers
  return `t_${nowTs()}_${Math.random().toString(16).slice(2)}`
}

function cleanString(value) {
  if (typeof value !== 'string') return ''
  return value.trim()
}

function normalizePriority(value) {
  const p = cleanString(value).toLowerCase()
  return PRIORITIES.includes(p) ? p : 'medium'
}

function normalizeDueDate(value) {
  const s = cleanString(value)
  // We store and edit as YYYY-MM-DD (date input format).
  // Keep empty string as "no due date".
  if (!s) return ''
  return s
}

export function normalizeTask(raw) {
  const title = cleanString(raw?.title)
  const description = cleanString(raw?.description)
  const createdAt = Number.isFinite(raw?.createdAt) ? raw.createdAt : nowTs()
  const updatedAt = Number.isFinite(raw?.updatedAt) ? raw.updatedAt : createdAt

  return {
    id: cleanString(raw?.id) || createId(),
    title,
    description,
    priority: normalizePriority(raw?.priority),
    dueDate: normalizeDueDate(raw?.dueDate),
    completed: Boolean(raw?.completed),
    createdAt,
    updatedAt,
  }
}

export function normalizeTasks(rawList) {
  if (!Array.isArray(rawList)) return []
  return rawList.map(normalizeTask)
}

export function createTask(data) {
  const createdAt = nowTs()
  return normalizeTask({
    ...data,
    id: createId(),
    completed: false,
    createdAt,
    updatedAt: createdAt,
  })
}

export function applyTaskPatch(task, patch) {
  return normalizeTask({
    ...task,
    ...patch,
    id: task.id,
    createdAt: task.createdAt,
    updatedAt: nowTs(),
  })
}
