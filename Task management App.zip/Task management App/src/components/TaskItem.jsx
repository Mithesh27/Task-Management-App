import { useEffect, useMemo, useState } from 'react'

function formatDue(dueDate) {
  if (!dueDate) return ''
  return dueDate
}

function priorityBadgeClass(priority) {
  if (priority === 'low') return 'badge badgeLow'
  if (priority === 'high') return 'badge badgeHigh'
  return 'badge badgeMedium'
}

function priorityLabel(priority) {
  if (priority === 'low') return 'Low'
  if (priority === 'high') return 'High'
  return 'Medium'
}

export function TaskItem({ task, onToggleComplete, onDelete, onUpdate }) {
  const [isEditing, setIsEditing] = useState(false)

  const [title, setTitle] = useState(task.title)
  const [description, setDescription] = useState(task.description)
  const [dueDate, setDueDate] = useState(task.dueDate || '')
  const [priority, setPriority] = useState(task.priority || 'medium')
  const [error, setError] = useState('')

  useEffect(() => {
    if (!isEditing) return
    // keep form in sync if task updates while editing is toggled by parent
    setTitle(task.title)
    setDescription(task.description)
    setDueDate(task.dueDate || '')
    setPriority(task.priority || 'medium')
    setError('')
  }, [isEditing, task])

  const badgeClass = useMemo(() => priorityBadgeClass(task.priority), [task.priority])
  const due = formatDue(task.dueDate)

  function startEdit() {
    setIsEditing(true)
  }

  function cancelEdit() {
    setIsEditing(false)
    setTitle(task.title)
    setDescription(task.description)
    setDueDate(task.dueDate || '')
    setPriority(task.priority || 'medium')
    setError('')
  }

  function saveEdit() {
    const t = title.trim()
    if (!t) {
      setError('Title is required.')
      return
    }
    onUpdate?.(task.id, {
      title: t,
      description,
      dueDate,
      priority,
    })
    setIsEditing(false)
  }

  function confirmDelete() {
    const ok = window.confirm('Delete this task? This cannot be undone.')
    if (!ok) return
    onDelete?.(task.id)
  }

  if (isEditing) {
    return (
      <div className="task">
        <div className="stack">
          <div className="row" style={{ gap: 10 }}>
            <div className="field" style={{ flex: 1 }}>
              <label>Title *</label>
              <input
                className="input"
                value={title}
                onChange={(e) => {
                  setTitle(e.target.value)
                  if (error) setError('')
                }}
              />
              {error ? <div className="errorText">{error}</div> : null}
            </div>
            <div className="field" style={{ width: 160 }}>
              <label>Priority</label>
              <select className="select" value={priority} onChange={(e) => setPriority(e.target.value)}>
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
              </select>
            </div>
          </div>

          <div className="row" style={{ gap: 10 }}>
            <div className="field" style={{ flex: 1 }}>
              <label>Due date</label>
              <input
                className="input"
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
              />
            </div>
            <div className="field" style={{ flex: 2 }}>
              <label>Description</label>
              <input
                className="input"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Optional"
              />
            </div>
          </div>

          <div className="rowBetween">
            <div className="muted" style={{ fontSize: 12 }}>
              Editing task…
            </div>
            <div className="taskActions">
              <button type="button" className="btn" onClick={cancelEdit}>
                Cancel
              </button>
              <button type="button" className="btn btnPrimary" onClick={saveEdit}>
                Save
              </button>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="task">
      <div className="taskTop">
        <div className="taskTitleRow">
          <input
            className="checkbox"
            type="checkbox"
            checked={task.completed}
            onChange={() => onToggleComplete?.(task.id)}
            aria-label={task.completed ? 'Mark incomplete' : 'Mark complete'}
          />
          <div style={{ minWidth: 0 }}>
            <h3 className={`taskTitle ${task.completed ? 'completed' : ''}`}>{task.title}</h3>
            <div className="taskMeta">
              <span className={badgeClass}>
                <span className="badgeDot" />
                {priorityLabel(task.priority)}
              </span>
              {due ? <span className="badge">Due: {due}</span> : null}
              {task.description ? <span className="badge">Note</span> : null}
            </div>
          </div>
        </div>

        <div className="taskActions">
          <button type="button" className="btn" onClick={startEdit}>
            Edit
          </button>
          <button type="button" className="btn btnDanger" onClick={confirmDelete}>
            Delete
          </button>
        </div>
      </div>

      {task.description ? (
        <>
          <div className="divider" />
          <div className="muted" style={{ fontSize: 13, whiteSpace: 'pre-wrap' }}>
            {task.description}
          </div>
        </>
      ) : null}
    </div>
  )
}

