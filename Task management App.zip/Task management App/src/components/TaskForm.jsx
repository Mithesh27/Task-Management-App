import { useMemo, useState } from 'react'

const PRIORITY_OPTIONS = [
  { value: 'low', label: 'Low' },
  { value: 'medium', label: 'Medium' },
  { value: 'high', label: 'High' },
]

export function TaskForm({ onAdd }) {
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [dueDate, setDueDate] = useState('')
  const [priority, setPriority] = useState('medium')
  const [error, setError] = useState('')

  const canSubmit = useMemo(() => title.trim().length > 0, [title])

  function reset() {
    setTitle('')
    setDescription('')
    setDueDate('')
    setPriority('medium')
    setError('')
  }

  function onSubmit(e) {
    e.preventDefault()
    const t = title.trim()
    if (!t) {
      setError('Title is required.')
      return
    }

    onAdd?.({
      title: t,
      description,
      dueDate,
      priority,
    })
    reset()
  }

  return (
    <form className="stack" onSubmit={onSubmit}>
      <div className="field">
        <label htmlFor="task-title">Title *</label>
        <input
          id="task-title"
          className="input"
          value={title}
          onChange={(e) => {
            setTitle(e.target.value)
            if (error) setError('')
          }}
          placeholder="e.g. Pay rent"
          autoComplete="off"
        />
        {error ? <div className="errorText">{error}</div> : null}
      </div>

      <div className="field">
        <label htmlFor="task-desc">Description</label>
        <textarea
          id="task-desc"
          className="textarea"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Optional notes..."
        />
      </div>

      <div className="row">
        <div className="field" style={{ flex: 1 }}>
          <label htmlFor="task-due">Due date</label>
          <input
            id="task-due"
            className="input"
            type="date"
            value={dueDate}
            onChange={(e) => setDueDate(e.target.value)}
          />
        </div>
        <div className="field" style={{ flex: 1 }}>
          <label htmlFor="task-priority">Priority</label>
          <select
            id="task-priority"
            className="select"
            value={priority}
            onChange={(e) => setPriority(e.target.value)}
          >
            {PRIORITY_OPTIONS.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="rowBetween">
        <div className="muted" style={{ fontSize: 12 }}>
          Tasks are saved automatically in your browser.
        </div>
        <button className="btn btnPrimary" type="submit" disabled={!canSubmit}>
          Add task
        </button>
      </div>
    </form>
  )
}

