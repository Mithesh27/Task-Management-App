const FILTERS = [
  { id: 'all', label: 'All' },
  { id: 'active', label: 'Active' },
  { id: 'completed', label: 'Completed' },
]

export function TaskFilters({ filter, onFilterChange, query, onQueryChange, counts }) {
  return (
    <div className="stack">
      <div className="pillRow" role="tablist" aria-label="Task filters">
        {FILTERS.map((f) => {
          const pressed = filter === f.id
          const count =
            f.id === 'all'
              ? counts?.all ?? 0
              : f.id === 'active'
                ? counts?.active ?? 0
                : counts?.completed ?? 0

          return (
            <button
              key={f.id}
              type="button"
              className="pill"
              aria-pressed={pressed}
              onClick={() => onFilterChange?.(f.id)}
            >
              {f.label} ({count})
            </button>
          )
        })}
      </div>

      <div className="field">
        <label htmlFor="task-search">Search</label>
        <input
          id="task-search"
          className="input"
          value={query}
          onChange={(e) => onQueryChange?.(e.target.value)}
          placeholder="Search by title..."
          autoComplete="off"
        />
      </div>
    </div>
  )
}

