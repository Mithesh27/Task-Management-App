import { TaskItem } from './TaskItem.jsx'

export function TaskList({ tasks, onToggleComplete, onDelete, onUpdate }) {
  if (!tasks.length) {
    return (
      <div className="empty">
        <div style={{ fontWeight: 600, marginBottom: 6 }}>No tasks here yet</div>
        <div className="muted" style={{ fontSize: 13 }}>
          Add a task on the left, or clear your filters/search.
        </div>
      </div>
    )
  }

  return (
    <div className="list">
      {tasks.map((t) => (
        <TaskItem
          key={t.id}
          task={t}
          onToggleComplete={onToggleComplete}
          onDelete={onDelete}
          onUpdate={onUpdate}
        />
      ))}
    </div>
  )
}

