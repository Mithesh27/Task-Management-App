import { useEffect, useMemo, useState } from 'react'
import { TaskForm } from './components/TaskForm.jsx'
import { TaskFilters } from './components/TaskFilters.jsx'
import { TaskList } from './components/TaskList.jsx'
import { loadTasks, saveTasks } from './utils/storage.js'
import { applyTaskPatch, createTask } from './utils/taskModel.js'

function getCounts(tasks) {
  const completed = tasks.reduce((acc, t) => acc + (t.completed ? 1 : 0), 0)
  return {
    all: tasks.length,
    completed,
    active: tasks.length - completed,
  }
}

export default function App() {
  const [tasks, setTasks] = useState([])
  const [filter, setFilter] = useState('all') // all | active | completed
  const [query, setQuery] = useState('')

  useEffect(() => {
    setTasks(loadTasks())
  }, [])

  useEffect(() => {
    saveTasks(tasks)
  }, [tasks])

  function addTask(data) {
    const t = createTask(data)
    setTasks((prev) => [t, ...prev])
  }

  function updateTask(id, patch) {
    setTasks((prev) => prev.map((t) => (t.id === id ? applyTaskPatch(t, patch) : t)))
  }

  function toggleComplete(id) {
    setTasks((prev) =>
      prev.map((t) => (t.id === id ? applyTaskPatch(t, { completed: !t.completed }) : t)),
    )
  }

  function deleteTask(id) {
    setTasks((prev) => prev.filter((t) => t.id !== id))
  }

  const counts = useMemo(() => getCounts(tasks), [tasks])

  const visibleTasks = useMemo(() => {
    const q = query.trim().toLowerCase()

    const filtered = tasks.filter((t) => {
      if (filter === 'active' && t.completed) return false
      if (filter === 'completed' && !t.completed) return false
      if (q && !t.title.toLowerCase().includes(q)) return false
      return true
    })

    return [...filtered].sort((a, b) => b.createdAt - a.createdAt)
  }, [tasks, filter, query])

  return (
    <div className="app">
      <div className="container">
        <div className="header">
          <div>
            <h1 className="title">Task Manager</h1>
            <p className="subtitle">
              {counts.active} active · {counts.completed} completed · {counts.all} total
            </p>
          </div>
        </div>

        <div className="grid">
          <div className="card">
            <div className="cardHeader">
              <div className="rowBetween">
                <div style={{ fontWeight: 650 }}>New task</div>
                <div className="muted" style={{ fontSize: 12 }}>
                  Create
                </div>
              </div>
              <div className="divider" />
            </div>
            <div className="cardBody">
              <TaskForm onAdd={addTask} />
            </div>
          </div>

          <div className="card">
            <div className="cardHeader">
              <div className="rowBetween">
                <div style={{ fontWeight: 650 }}>Your tasks</div>
                <div className="muted" style={{ fontSize: 12 }}>
                  Read · Update · Delete
                </div>
              </div>
              <div className="divider" />
            </div>
            <div className="cardBody">
              <div className="stack">
                <TaskFilters
                  filter={filter}
                  onFilterChange={setFilter}
                  query={query}
                  onQueryChange={setQuery}
                  counts={counts}
                />
                <TaskList
                  tasks={visibleTasks}
                  onToggleComplete={toggleComplete}
                  onDelete={deleteTask}
                  onUpdate={updateTask}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
